<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_thats all really</name>
   <tag></tag>
   <elementGuidId>e4973830-e8e0-4c49-95f4-59e37cf6b225</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#contactForm > div.row > div.col-12</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='contactForm']/div/div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#contactForm div >> internal:has-text=&quot;thats all? really?&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b8939875-6636-4c61-981c-598958d38145</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-12</value>
      <webElementGuid>52a42e6b-b091-438e-9fc5-85686daf59b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                  thats all? really?
                
              </value>
      <webElementGuid>2e3e92a0-6b9e-4014-9ef6-7ce66be845d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contactForm&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]</value>
      <webElementGuid>48546634-0b3a-43ec-8c75-415a2377d757</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='contactForm']/div/div[4]</value>
      <webElementGuid>48511c01-d2e1-49b7-b1c9-0a42e6c511e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thông tin liên hệ'])[1]/following::div[9]</value>
      <webElementGuid>8061cacc-ef6c-4b03-8a99-6447cb89e145</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Liên hệ'])[3]/following::div[13]</value>
      <webElementGuid>da100da5-c984-4919-879c-fef37905c811</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thông tin liên hệ gửi không thành công, vui lòng thử lại!'])[1]/preceding::div[4]</value>
      <webElementGuid>3d32998c-1120-4e6c-ab8e-58b8064d7f22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]</value>
      <webElementGuid>347c6b52-fa00-44d3-9a06-521de12d9f0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                  thats all? really?
                
              ' or . = '
                
                  thats all? really?
                
              ')]</value>
      <webElementGuid>07961ae8-9c5e-4978-8011-f41db35fc7f4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

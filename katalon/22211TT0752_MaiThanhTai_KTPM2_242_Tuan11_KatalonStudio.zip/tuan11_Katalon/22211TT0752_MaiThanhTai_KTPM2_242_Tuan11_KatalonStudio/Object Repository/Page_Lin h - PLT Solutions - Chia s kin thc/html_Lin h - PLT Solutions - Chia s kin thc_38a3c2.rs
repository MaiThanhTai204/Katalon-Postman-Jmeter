<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>html_Lin h - PLT Solutions - Chia s kin thc_38a3c2</name>
   <tag></tag>
   <elementGuidId>2803b49b-e8fe-4926-9bdc-ce16ab7d8fb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>html.sizes.customelements.history.pointerevents.postmessage.webgl.websockets.cssanimations.csscolumns.csscolumns-width.csscolumns-span.csscolumns-fill.csscolumns-gap.csscolumns-rule.csscolumns-rulecolor.csscolumns-rulestyle.csscolumns-rulewidth.csscolumns-breakbefore.csscolumns-breakafter.csscolumns-breakinside.flexbox.picture.srcset.webworkers</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='']/parent::*</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>html</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
      <webElementGuid>398d2260-7352-4adb-af64-fec2f6997ee5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>en</value>
      <webElementGuid>e8dc4896-b351-4239-b6c7-1bbf00bef8f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers</value>
      <webElementGuid>3bd5714a-b3b2-4290-aec6-60e15ac0df0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  
  
  

      Liên hệ - PLT Solutions - Chia sẻ kiến thức


















  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon katalon-div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} katalon-div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} katalon-div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}




  
  
    
      
        
        
          
        
      
    
  

  

  
  
    
      
        
        
          
            
            
            
             
          
        
        
          
            
              
                
                  
                    
                  
                  
                    0974660075
                  
                
              
            
          
        
      
      
        
        
          
            
          
        
        
          
            
            
              
                
              
            
            
            
              
                
                  Trang chủ
                  Chúng tôi
                  Khoá học
                  Nhân sự
                  Workshop
                  Tin tức
                  Bài viết
                  Sản phẩm
                  Liên hệ
                
              
            
            
            
              
                
                
                  
                
              
            
          
          
          
            MENU
                  Trang chủ
                  Chúng tôi
                  Khoá học
                  Nhân sự
                  Workshop
                  Tin tức
                  Bài viết
                  Sản phẩm
                  Liên hệ
                
          
        
      
    
  
  


    
  
    
      
        
          
            
              Liên hệ
            
          
        
      
    
  
  
  
  
    
      
        
      
      
        
          Thông tin liên hệ
        
        
          
                        
              
                
                  
                
              
              
                
                  
                
              
              
                
                  
                
              
              
                
                  thats all? really?
                
              
            
            
              
                
              
              
                Thông tin liên hệ gửi không thành công, vui lòng thử lại!
              
            
            
              Gửi
            
          
        
        
          
            
            
              T39 đường 14, KDC Ehome 4, phường Vĩnh Phú, TP. Thuận An, tỉnh Bình Dương
              Địa chỉ của chúng tôi
            
          
          
            
            
              0974660075
              Gọi ngay cho chúng tôi để được tư vấn
            
          
          
            
            
              pltsolutions3010@gmail.com
              Gửi cho chúng tôi câu hỏi của bạn bất cứ lúc nào!
            
          
        
      
    
  
  



  
  
    
      
        
        
          
            
              
                Góp ý kiến
              
              
              
                
                  
                    
                    
                      
                        Subscribe Now
                      
                    
                    
                  
                
              
            
            
              
                Mạng xã hội
              
              
              
                
                
                
                
              
            
          
        
      
      
      
        
          
            
              
                Copyright ©document.write(new Date().getFullYear());2025 All rights reserved |   PLt Solutions
                
            
          
        
      
    
  
  




   










































/html[@class=&quot;sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers&quot;]</value>
      <webElementGuid>47375f20-f8bb-4db8-840b-987c15709c82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers&quot;]</value>
      <webElementGuid>cca327cd-4c31-4ebd-81ed-0b1e2a0008dc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='']/parent::*</value>
      <webElementGuid>0fb3fe7a-11a4-4433-86ea-ccfd22f2c7bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
      <webElementGuid>632d4ce9-2642-430a-b2b2-53b0e8449231</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//html[(text() = '
  
  
  

      Liên hệ - PLT Solutions - Chia sẻ kiến thức


















  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon katalon-div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} katalon-div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} katalon-div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}




  
  
    
      
        
        
          
        
      
    
  

  

  
  
    
      
        
        
          
            
            
            
             
          
        
        
          
            
              
                
                  
                    
                  
                  
                    0974660075
                  
                
              
            
          
        
      
      
        
        
          
            
          
        
        
          
            
            
              
                
              
            
            
            
              
                
                  Trang chủ
                  Chúng tôi
                  Khoá học
                  Nhân sự
                  Workshop
                  Tin tức
                  Bài viết
                  Sản phẩm
                  Liên hệ
                
              
            
            
            
              
                
                
                  
                
              
            
          
          
          
            MENU
                  Trang chủ
                  Chúng tôi
                  Khoá học
                  Nhân sự
                  Workshop
                  Tin tức
                  Bài viết
                  Sản phẩm
                  Liên hệ
                
          
        
      
    
  
  


    
  
    
      
        
          
            
              Liên hệ
            
          
        
      
    
  
  
  
  
    
      
        
      
      
        
          Thông tin liên hệ
        
        
          
                        
              
                
                  
                
              
              
                
                  
                
              
              
                
                  
                
              
              
                
                  thats all? really?
                
              
            
            
              
                
              
              
                Thông tin liên hệ gửi không thành công, vui lòng thử lại!
              
            
            
              Gửi
            
          
        
        
          
            
            
              T39 đường 14, KDC Ehome 4, phường Vĩnh Phú, TP. Thuận An, tỉnh Bình Dương
              Địa chỉ của chúng tôi
            
          
          
            
            
              0974660075
              Gọi ngay cho chúng tôi để được tư vấn
            
          
          
            
            
              pltsolutions3010@gmail.com
              Gửi cho chúng tôi câu hỏi của bạn bất cứ lúc nào!
            
          
        
      
    
  
  



  
  
    
      
        
        
          
            
              
                Góp ý kiến
              
              
              
                
                  
                    
                    
                      
                        Subscribe Now
                      
                    
                    
                  
                
              
            
            
              
                Mạng xã hội
              
              
              
                
                
                
                
              
            
          
        
      
      
      
        
          
            
              
                Copyright ©document.write(new Date().getFullYear());2025 All rights reserved |   PLt Solutions
                
            
          
        
      
    
  
  




   










































/html[@class=&quot;sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers&quot;]' or . = '
  
  
  

      Liên hệ - PLT Solutions - Chia sẻ kiến thức


















  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon katalon-div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} katalon-div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} katalon-div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}




  
  
    
      
        
        
          
        
      
    
  

  

  
  
    
      
        
        
          
            
            
            
             
          
        
        
          
            
              
                
                  
                    
                  
                  
                    0974660075
                  
                
              
            
          
        
      
      
        
        
          
            
          
        
        
          
            
            
              
                
              
            
            
            
              
                
                  Trang chủ
                  Chúng tôi
                  Khoá học
                  Nhân sự
                  Workshop
                  Tin tức
                  Bài viết
                  Sản phẩm
                  Liên hệ
                
              
            
            
            
              
                
                
                  
                
              
            
          
          
          
            MENU
                  Trang chủ
                  Chúng tôi
                  Khoá học
                  Nhân sự
                  Workshop
                  Tin tức
                  Bài viết
                  Sản phẩm
                  Liên hệ
                
          
        
      
    
  
  


    
  
    
      
        
          
            
              Liên hệ
            
          
        
      
    
  
  
  
  
    
      
        
      
      
        
          Thông tin liên hệ
        
        
          
                        
              
                
                  
                
              
              
                
                  
                
              
              
                
                  
                
              
              
                
                  thats all? really?
                
              
            
            
              
                
              
              
                Thông tin liên hệ gửi không thành công, vui lòng thử lại!
              
            
            
              Gửi
            
          
        
        
          
            
            
              T39 đường 14, KDC Ehome 4, phường Vĩnh Phú, TP. Thuận An, tỉnh Bình Dương
              Địa chỉ của chúng tôi
            
          
          
            
            
              0974660075
              Gọi ngay cho chúng tôi để được tư vấn
            
          
          
            
            
              pltsolutions3010@gmail.com
              Gửi cho chúng tôi câu hỏi của bạn bất cứ lúc nào!
            
          
        
      
    
  
  



  
  
    
      
        
        
          
            
              
                Góp ý kiến
              
              
              
                
                  
                    
                    
                      
                        Subscribe Now
                      
                    
                    
                  
                
              
            
            
              
                Mạng xã hội
              
              
              
                
                
                
                
              
            
          
        
      
      
      
        
          
            
              
                Copyright ©document.write(new Date().getFullYear());2025 All rights reserved |   PLt Solutions
                
            
          
        
      
    
  
  




   










































/html[@class=&quot;sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers&quot;]')]</value>
      <webElementGuid>1cc127e6-5e74-4205-adf8-6ecac5f8bc41</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Tip tc mua hng</name>
   <tag></tag>
   <elementGuidId>729f86e2-2f41-4790-85c3-0d372f752bbb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-default</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/form/div[2]/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Tiếp tục mua hàng&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4681e1ac-cb99-40e7-9929-23a74315b086</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://pltpro.net</value>
      <webElementGuid>3f33b3d8-d6bb-4e09-8d44-fcbe340c6916</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default</value>
      <webElementGuid>f6b638eb-b972-4704-a9c4-4937f6fe3681</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Tiếp tục mua hàng</value>
      <webElementGuid>471f9939-b4d7-4d7f-aaed-09da953e72f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/form[1]/div[@class=&quot;buttons&quot;]/div[@class=&quot;pull-left&quot;]/a[@class=&quot;btn btn-default&quot;]</value>
      <webElementGuid>0a7e29be-d0ea-4c0b-860a-843c9cb5abdb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/form/div[2]/div/a</value>
      <webElementGuid>02d4760c-b98f-4ff5-9116-4e13e48efeb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Tiếp tục mua hàng')]</value>
      <webElementGuid>bd7819ed-f558-452e-81ea-d66bcef11409</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ghi chú'])[1]/following::a[1]</value>
      <webElementGuid>224e6f67-6cd7-40bb-b491-06e65dacaab6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Địa chỉ'])[1]/following::a[1]</value>
      <webElementGuid>2f4aadb6-728a-488e-9b35-c636a67955c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hoàn tất đặt hàng'])[1]/preceding::a[1]</value>
      <webElementGuid>5df73ed8-6903-433d-8eee-ef683ea138b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thương hiệu nổi bật'])[1]/preceding::a[1]</value>
      <webElementGuid>b58c41dc-4487-4256-b75c-e8e5cc638f1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Tiếp tục mua hàng']/parent::*</value>
      <webElementGuid>bf99c96f-de20-4ace-8c13-f0c2e1672db8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://pltpro.net')])[128]</value>
      <webElementGuid>dcd3fdcb-3eab-4645-8fa6-1eb4e477e0b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[2]/div/a</value>
      <webElementGuid>acfc000e-727f-465c-b5fb-6eb4e320ff7e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://pltpro.net' and (text() = 'Tiếp tục mua hàng' or . = 'Tiếp tục mua hàng')]</value>
      <webElementGuid>9ad55bd9-bf8e-4cba-b42c-7992dc50eaa8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

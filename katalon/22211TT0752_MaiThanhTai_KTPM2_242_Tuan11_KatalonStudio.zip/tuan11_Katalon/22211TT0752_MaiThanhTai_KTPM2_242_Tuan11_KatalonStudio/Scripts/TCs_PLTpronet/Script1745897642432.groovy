import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://pltpro.net/san-pham/1766/lenovo-e580-thi-truong-nhat-manh-me-core-i5-th8-ram-8gb-ssd-128gb-hdd-500gb-pin-lau-3-4h')

WebUI.setText(findTestObject('Object Repository/Page_LENOVO E580 TH TRNG NHT MNH M, CORE I5_624966/input_S lng_Quantity'), 
    soluong)

WebUI.click(findTestObject('Object Repository/Page_LENOVO E580 TH TRNG NHT MNH M, CORE I5_624966/button_Thm vo gi hng'))

WebUI.setText(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/input_LENOVO E580 TH TRNG NHT MNH  M, CORE _f3f92c'), 
    tongsoluong)

WebUI.setText(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/input__Name'), hovaten)

WebUI.setText(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/input__Phone'), sodienthoai)

WebUI.setText(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/input_Email_Email'), email)

WebUI.setText(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/input_a ch_Address'), diachi)

WebUI.setText(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/textarea_Ghi ch_Note'), ghichu)

WebUI.click(findTestObject('Object Repository/Page_Gi hng - PLT SOLUTIONS (Panda Laptop)/a_Tip tc mua hng'))


<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_LienHe</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5819779d-087d-409c-96dc-ce5a1e26a6ba</testSuiteGuid>
   <testCaseLink>
      <guid>99ef15c9-d810-449a-8403-58221dbf6332</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TCs_LienHe</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>1d498f72-fd35-4a3a-83c5-2871ecd45e5a</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Data_LienHe</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>1d498f72-fd35-4a3a-83c5-2871ecd45e5a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Họ và tên</value>
         <variableId>f31790a1-5c48-48d7-be9a-fbea38e96e21</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1d498f72-fd35-4a3a-83c5-2871ecd45e5a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>5b56a35b-36bb-4ee0-bc08-71a94d21c373</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1d498f72-fd35-4a3a-83c5-2871ecd45e5a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Số điện thoại</value>
         <variableId>28e1b89d-68b1-4a4c-a7d9-ae0aea572491</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1d498f72-fd35-4a3a-83c5-2871ecd45e5a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Ghi chú</value>
         <variableId>bf792ff3-9efa-401b-9f17-9f5e513e1e63</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>

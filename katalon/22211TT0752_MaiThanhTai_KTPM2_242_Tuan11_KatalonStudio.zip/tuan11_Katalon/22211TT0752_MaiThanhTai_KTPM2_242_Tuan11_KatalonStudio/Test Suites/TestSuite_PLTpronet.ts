<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_PLTpronet</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>1c42a651-c327-41a6-866b-2cfdcf8d7635</testSuiteGuid>
   <testCaseLink>
      <guid>54e6916f-1317-4473-ace2-bb3bd74cd17b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TCs_PLTpronet</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Data_PLTpronet</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Số lượng thêm vào giỏ hàng</value>
         <variableId>3288eee0-9777-4b96-9c1e-0045f405ea6f</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Tổng số lượng thêm vào giỏ hàng</value>
         <variableId>19497d71-15b1-4897-b88d-aed84cda93a4</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Họ và tên</value>
         <variableId>eaf86112-13ed-4f2d-8698-3754f93745f9</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Số điện thoại</value>
         <variableId>69da17a3-f92d-4eca-a549-3f8f5b160b02</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>6eaa6fc1-1dd0-4407-8606-32cbcba2d876</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Địa chỉ</value>
         <variableId>479619e1-a8fb-4bb1-a39f-ea339c851b69</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>b5995e92-9561-4b9f-b0f4-8a5df141f8ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Ghi chú</value>
         <variableId>19ca30ef-e63f-4bb8-9b0f-f976ae6201ab</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
